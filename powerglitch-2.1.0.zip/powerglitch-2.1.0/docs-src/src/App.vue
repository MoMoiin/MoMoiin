<template>
    <RouterView class="h-full w-full" />
</template>
